
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:gabay_app/AbwaanModel.dart';
import 'package:gabay_app/Abwaano/Abshir.dart';
import 'package:gabay_app/Abwaano/RaageUgaas.dart';
import 'package:gabay_app/Abwaano/Sayidka.dart';
import 'package:gabay_app/Abwaano/Timacade.dart';
import 'package:gabay_app/Abwaano/hadraawi.dart';
import 'package:gabay_app/drawer.dart';
import 'package:google_nav_bar/google_nav_bar.dart';

import 'Abwaano/Xaashi.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  

  @override
  Widget build(BuildContext context) {
    final User=FirebaseAuth.instance.currentUser!;
    return Scaffold(
      drawer: drawe(),
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Container(child: Text(User.email??'',style: TextStyle(fontSize: 20,color: Colors.white),)),
        backgroundColor: Color.fromARGB(255, 108, 232, 249),      
        elevation: 0,
        actions: [
          GestureDetector(
            onTap: () => FirebaseAuth.instance.signOut(),
            child: Container(
              margin: EdgeInsets.only(right: 10),
              child: Icon(Icons.logout,color: Colors.white,),
            ),
          )
        ],
      ),
      body: ListView(
        children: [
          GestureDetector(
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => Hadraawi(),));
            },
            child: Abwaan(magac: 'Maxamed Ibrahim Hadraawi',img: 'Images/Hadrawi.jpg',Gabayo: '8 Gabay',)),
          GestureDetector(
            onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => sayidka(),));

            },
            child: Abwaan(magac: 'Sayid Maxamed cabdale  xasan',img: 'Images/sayid.jpg',Gabayo: '9 Gabay',)),
          GestureDetector(
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => Gaariye(),));              
            },
            child: Abwaan(magac: 'Maxamed Xaashi Gaariye',img: 'Images/mxaashi.jpg',Gabayo: '5 gabay',)),
          GestureDetector(
            onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => Raage(),));              
            },
            child: Abwaan(magac: 'Raage Ugaasi',img: 'Images/Raage ugaas.jpg',Gabayo: '7 Gabay',)),
          GestureDetector(
            onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => Timacade(),));

            },
            child: Abwaan(magac: 'Suldaan Timacade',img: 'Images/Timacade.jpg',Gabayo: '4 Gabay',)),
          GestureDetector(
            onTap: () {
                 Navigator.push(context, MaterialPageRoute(builder: (context) => Abshir(),));

            },
            child: Abwaan(magac: 'Abshir Bacadle',img: 'Images/Abshir Bacadle.jpg',Gabayo: '1 Gabay',)),
            
          
        ],
      ),
        
    );
  }
}

class Abwaan extends StatelessWidget {
  const Abwaan({
    Key? key,  required this.img, required this.magac, required this.Gabayo,  
  }) : super(key: key);
final String img;
final String magac;
final String Gabayo;

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 130,
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12)
        ),
        child: Row(
          children: [
            Container(margin: EdgeInsets.only(left: 10), child: 
            ClipOval(child: Image.asset(img,height: 100,width: 100,fit: BoxFit.cover,))),
            Container(
              child: Container(
                margin: EdgeInsets.only(left: 15,top: 30),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  
                  Text(magac,style: TextStyle(fontSize: 18,fontWeight: FontWeight.w500),),
                  SizedBox(height: 10,),
                  Text(Gabayo,style: TextStyle(fontSize: 18,fontWeight: FontWeight.w500),),

                ],
            ),
              ))
          ],
        ),
      );
  }
}





// Container(
//         margin: EdgeInsets.only(left: 15,right: 10),
//         child: ListView(
//           children: [
//             SizedBox(height: 10,),
//             Abwaan()
//           ],
//         ),
//       ),



// ListView.builder(
//       itemCount: Gabayo.length, 
//       itemBuilder: (context, index) => Abwaan(
//         ab: Gabayo[index],
//       ),)
// ElevatedButton(onPressed:() =>FirebaseAuth.instance.signOut(), child: Text('Logout'))