class GabayoModel{
  String? title;
  String? gabayga;

GabayoModel({
  this.title,
  this.gabayga
});
}