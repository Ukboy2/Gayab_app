import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:gabay_app/GabayoModel.dart';

class Timacade extends StatelessWidget {
   Timacade({Key? key}) : super(key: key);
  List<GabayoModel> gb=[
    
   
    GabayoModel(
      title: 'kaan Siib Kan Saar',
      gabayga: '''
Anigoo sebi uun ahoo         
Sita leeb iyo qaansoo
Siigaduun isku aasoo         
Sabo reer ka fogaanoon
Laygu aaminin soofkiyo       
Saaca maanta aan joogno
Gabaygu waygu sugnaayee      
Haddii aan Sarsarriigo
Ama aan surmaseejo           
Amaba aan sixi waayo
Ama aan ka salguuro          
Amaba laygu saluugo
Soomaalida i maqlaysaay      
I su'aala hadhow

Ilaahaan waxba seegine       
Subaciisa Quraankiyo
Sabbaxooyin ku sheegayow     
Saciira iyo naciima
Rabbiigii kala seerayow`     
Markay suurtu dhawaaqdo e
La soo saaro makhluuqa e     
Shaqiga iyo saciidka
Maalintaad kala soocdo       
Dembigaannu samaynay
Rabbigayow naga saamax

Subciyay oo ka dukeeyaye     
Ka siddeetan sebaaney
Calankaannu sugaynaye        
Sahankiisa ahaynow
Seermaweydo hillaacdayow     
Sagal maanta darroorayoo
Siigadii naga maydhayow      
Saq dhexaannu ahayne
Kii soo saaray cadceeddow    
Samada kii u ekaaye
xiddigaa mid la siiyayow     
Saaxirkii kala guurrayeaha
Sarreeyow ma-nusqaamow       
An siduu yahay eegno e
Kaana siib Kanna saar

Saahidiinta lslaamka e       
Subcisaa Jimcayaashiyo
Sibyaanta iyo haweenku       
Calankay Saadinayeenow
Cidina kaanay na Siine       
Saatir noogu yaboohayow
Saaxirkii kala guurraye      
Sarreeyow ma-nusqaamow
Aan siduu yahay eegno e      
Kaana siib kanna saar

Sallaankii istiqaalkow       
Sedadu kay ku xidhnaydow
Sayruukhii Afrikaadow        
Saaxirkii kala guurraye
Sarreeyow ma-nusqaamow       
An siduu yahay eegno e
Kaana siib kanna saar

San-ku-neefle dhammaantii     
Khalqiga kii u sinnaayeen
Mid saaxiib la ahayne         
Sangalkii iska diidayow
Saaxirkii kala guurraye       
Sarreeyow ma-nusqaamow
Aan siduu yahay eegno e       
Kaana siib kanna saar

Soomaloo iscunaysa oo         
Saqda qaylo dhawaaqdiyo
Sulub laysu cabbaystiyo       
Hadba soof la xabbaadhiyo
Saraayaa dami weyde           
Kii laydhiisu na saaqdayow
Kii sadqeeyey qabaa'ile       
Isu saaray gacmaa ee
Saf walaala ka yeelayow       
Saaxirkii kala guurraye
Sarreeyow ma-nusqaamow        
An siduu yahay eegno e
Kaana siib kanna saar

In sidayda tihiin iyo       
In kalaanan saxaynine
Soomaloo calan taagta        
Saakay noogu horraysa oo
Saddex wiig iyo maalmo       
Haddaan Soor cuni waayo
Safrad laygama yaaboo        
Sarina mayso naftayda e
Saaxirkii kala guurraye      
Sarreeyow ma-nusqaamow
An siduu yahay eegno e       
Kaana siib kanna saar

Nimankii na Siraayaye        
Waaxwaax noo kala saaftaye
Solanaayey cadkeenna e       
Innagoo dhexda suunku
Sabarkeenna qarqooray        
Kii sedkeenna Cunaayaye
Sarartiisa ka muuqdaye       
Surwaalkii ka yaraadaye
Daaro loo sibidheeyiyo       
Sariiraa lagu seexdiyo
Kabadh suuf laga buuxshiyo   
Mid baabuurka safeeyiyo
Aayad saarta carruuurtiyo    
Sagaal boy iyo kuug iyo
Weliba seeksa lahaa          
Kii saabaanka u laabayow
Saaxirkii kala gaurraye      
Sarreeyow ma-nusqaamow
An siduu yahay eegno e       
Kaana siib kanna saar

Sawjarkaa hubka qaataye      
Intuu soodhka ku taagey
U diyaara salaantiyo         
Saraakiisha amraysaay
Sifihii isticmaarka          
Ka siyaadiya maanta oo
Sibilkiinnan ag joogow       
Sibirtiisa istaaga oo
Nin walbaan sigib beeloo     
Sarow taaga gacmaa oo
Sacabkaysku garaaca oo       
Nin walbow saddex goor
Subxaanow waa mahaddaa dheh

Subxaanow waa mahadaa
Subxaanow waa mahadaa
Subxaanow waa mahadaa!
'''
    ),
    GabayoModel(
      title: 'Maandeeq',
      gabayga: '''

Gumaysigu hashuu naga dhacay           
een gurayey raadkeeda
gu'yaal iyo gu'yaal badan              
hashii gama'a noo diidey
goobtay istaagtaba hashaan             
joogay garabkeeda
guuraa habeenimo hashaan               
gebi walba u jiidhay
gaashaandhigeedii hashu                
galowgu eedaamay

hashii geeddankeedii rag badan         
goodku ku casheeyey
gacmaa lagu muquunshaye xornimo        
noogumay garane
garre iyo guntane maalintay            
gees isugu boodey
Allaa noo gargaaree xornimo            
noogumay garane
geeraarradeedii hashaan                
annigu googooyey

galool iyo maraa iyo hashaan           
kidiga geylaanshey
gaajiyo harraad badan hashaan          
ugu garaacaayay
goobtuu sidkeedii go'ay                
galabtii foolqaaday
ayadoo candhada giijisay               
oo godol ku sii deysay
Garaad midan lahayn bay                
la tahay waad ka gaagixine
annagoo gantaalaha dhaciyo             
haysan qori gaaban
hashaan gaadda weynow libaax           
uga gaboon waayey
Inaan Garayacawl uga tagaa             
waa hal soo gudhaye.
'''
    ),
    GabayoModel(
      title: 'Ragee',
      gabayga: '''


Markii malag Jibriil uu waxyiga Maxamad siinaayay
nimankii maroodiga koree magane kooraystay
Makka kuwii inay ku duulaan uunka maqashiiyay

meeshiyo Abraha waxay ahayd dawlad maatiyahe
maskaxdii gabowdiyo waqtigu waaba kala maane
haddii dhiig nin uun laga mutaa rag u macaanaado

malabsiga ayaamaad hadduu mahad ku noolaado
magool suna mar waa cunni jiriyo midho dhunkaaleede
wuxuu Xayle meehaday iyo malihii beenowye

meeshiyo Berbera wuxuu lahaa maalin baad qabane
Geel-jiraha maarraha sitaa madhiyay geeshkiiye
ma moodayn Amxaarada inuu mawdku soo wado'e

nagamuu macaashine markay miririgtii yeedhay
milatariga dhaarsani markuu moote ku asqeeyay
madaafiicda waaweyn markii midigta loo dhiibay

Mingistiyo colkiisii la waa meel uu joogaba'e
muruguu dibnaha ruugayoo uu madowyahaye
maantaan gadhkii midhiqsanaa mid uga taagnayne

minka baxaya faalkaan arkiyo feleggii kaa meerye
Yuhuu magansataa iyo Qarbigu kuu mashxaradyaaba
isku muuqan maynnee markay miiranto aan eegno

'''
    ),
    GabayoModel(
      title: 'Hooyale',
      gabayga: '''
Indhawaydba hooyale gabay hiigso ma lahayne
waa taan ka saahiday tixii hibadu saarayde
meeshiyo hilaaci kal hore maan haloosiine

dharaartaan haleelaan wixii hore ilaabaaye
hijradiisa goortaan dhex galo ha iyo wowgiisa
markaan anigu hoonka u tumo ayay haadka bixiyaane

hagaag uma talaabsado ninkaan hamaga saaraaye
waxaan gabaygan haatanna ku nacay hadimo waa heele
hadalada dul ow hoosta ay haaf ka dhigayaane

afartaa hilaac iyo tus iyo heego maw yeelay
hannaan gabayga waw marin jiree hadaladaydii dheh
hirara kalena waa maansaday hibatay laabtaydu

hal wanaagsan oo kuu dhashiyo hoos mid laga waayay
hadhuub inaanay wada buuxinayn hubati sow maaha
sange lagu horseediyo magaan hararaflaynaya

inaanay habaas wada galayn hubati saw maaha
hamadeenu bari bay ahayd heesta naagaha'e
heeladiyo barjuhu waa wixii hoos inoo dhigaye

hareeraha raga inaga xigaa helay libtoodiiye
heeryada gumaysiga ma rido ka u habranayaaye
lama helo wadaadow waxan ciddi u hawshoone

nafta loo hantaaqa waxay higso leedahaye
haween iyo rag waa loo guntaday hawshi barigiiye
gobanimdan hoobaan dhacday ee lagu haraad beelay

haydh-haydh haday naga ahayd haw ku soo nidhiye
haaneednay maandeeq Ilaah nama hungaysiine
diyaaraadka heegada mara ee haada la ciyaara

amikaarka hawsha u sita ee huriya duulaanka
dabaabadaha lagu hawdiyo maynka lagu haagmay
hubka iswada haydrogiinta iyo saanadaha haadha

hustankiyo afdheerha socdiyo haafafkiyo jiibka
raga taarka soo halabsady ee hadiyad noo siiyay
nin walba wuxuu noo huray buu hooya leeyahaye

habeen dhow wacane inaynu noqon waana la hubaaye
'''
    )
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
       backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Container(child: Text('Gabayadii Suldaan Timacade',style: TextStyle(fontSize: 20,color: Colors.white),)),
        backgroundColor: Color.fromARGB(255, 108, 232, 249),
        elevation: 0,
      ),
    body: ListView.builder(
            itemCount: gb.length, 
            itemBuilder: (context, index) => gabayo(
              gab: gb[index],
              ),)
    );
  }
}

class gabayo extends StatelessWidget {
  const gabayo({
    Key? key, required this.gab,
  }) : super(key: key);
final GabayoModel gab;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => Detail(gab: gab),));
      },
      child: Container(
       height: 80,
       width: double.infinity,
       padding: EdgeInsets.only(left: 20,top: 20),
       margin: EdgeInsets.only(top: 10),
       decoration: BoxDecoration(
         color: Colors.white,
         borderRadius: BorderRadius.circular(15)
       ),
       child: Text(gab.title??'',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
      ),
    );
  }
}








class Detail extends StatelessWidget {
  const Detail({Key? key, required this.gab}) : super(key: key);
final GabayoModel gab;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Container(child: Text(gab.title??'',style: TextStyle(fontSize: 20,color: Colors.white),)),
        backgroundColor: Color.fromARGB(255, 108, 232, 249),
        elevation: 0,
      ),
      body: ListView(
        children: [
          Container(
            margin: EdgeInsets.only(top: 35,left: 35,right: 20),
            
            width: double.infinity,
            
            child: Text(gab.gabayga??'',
            style: TextStyle(fontSize: 20,fontWeight: FontWeight.w400,),),
          )
        ],
      ),

    );
  }
}