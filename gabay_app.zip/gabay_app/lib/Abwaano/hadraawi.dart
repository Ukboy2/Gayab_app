import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:gabay_app/GabayoModel.dart';

class Hadraawi extends StatelessWidget {
   Hadraawi({Key? key}) : super(key: key);
  List<GabayoModel> gb=[
    GabayoModel(
      title: 'Hooyo',
      gabayga: '''Hooyooy  

Aduunyadu hubaashii

Habeen kama baxdeenoo

Iftin lama heleenoo

Dadku uma hayaameen

Xiddig hawd ka lulatoo

Sida haad ma fuuleen

Dayax heego joogoo

Hubka laguma tureen

Hawo laguma gaadheen

Cirka hirar ka muuqdoo

Hooyoy addoomuhu

Halkay maanta joogaan

Adigow horseedoo

Intaad hanad xambaartee

Haaneedka siisee

Horaaddada jaqsiisee

Habtay baan xisaab iyo 

Tiro lagu heleynoo. 

Marka aad nin hiilloo

Laga baqo hashiisiyo

Halyey diran dhashaa baa

Hooyo lagu xasuustaa

Marka aad nin hoo-loo

Gurigiisa habaqluhu

Isku soo halleeyoo

Hayntiisa quudhoo

Hor Illaahay geystiyo

Lama hure dhashaa baa

Hooyo lagu xasuustaa.

Mar aad nin himilada

Hilin toosan mariyoo

Hir markii la gaadhoba

Ku labaad hilaadshoo

Haga maatadiisoo

La higsado dhashaa baa

Hooyo lagu xasuustaa.

Marka aad nin hoogiyo

Ka hor taga daalkoo

Garta hubin yaqaanoo

Xaqa hoos u eegoo

Halistiyo colaadaha

Dabka hura bakhtiiyoo

Ku haggoogta dhiiggoo

Dadka kala hagaajoo

Kala haga dhashaa baa

Hooyo lagu xasuustaa.

Markaad hoobal caaniyo

Hindisaa farshaxanoo

Hab-dhaca iyo luuqdiyo

Hawraarta maansada

Heensayn yaqaanoo

Rabbi biyo u siiyoo

Labadaba hannaanshiyo

Hal-abuur dhashaa baa

Hooyo lagu xasuustaa.

Dumar iyo haween baa

Nolol lagu haweyntaa

Kuwa lagu hammiyayee

Sida hawd caleen weyn

Rag u wada hammuumee

Ishu calacsanaysaa

Hablahaaga weeyee

Marka guur la haybshee

Gabadh heego dheeroo

Hoobaan la moodoo

Karti iyo hubqaadloo

Quruxdana ka hodaniyo

Hira laga aroostaa

Hooyo lagu xasuustaa

Hooyoy la'aantaa 

Higgaad lama barteenoo

Hooyoy la'aantaa

Hadal lama kareenoo

Ruuxaanad habinoo

Kolba aanad hees iyo

Hoobey ku sabinoo

Hawshaada waayaa

Hanaqaadi maayee

Hoygii kalgacalkee

Naxariistu hadataay.
Hooyoy dushaadaa

Nabad lagu hubaayooo

Hooyoy dhabtaadaa

Hurdo lagu gam'aayoo

Hooyoy taftaadaa

Dugsi laga helaayoo

Waxa lagu hal-maalaa

Hooyo ababintaadee

Hayin lagu badhaadhaay

Hogol lagu qaboobaay

Gogol lama huraaneey

Dugsigii hufnaantaay

Hidda lagu arooraay.
Intaad hooyo nooshahay

Hambalyiyo salaan baan

Hanti kaaga dhigayaa

Hamrashiyo xaq dhowr baan

Dusha kaa huwinayaa

Hooyo dhimashadaaduna

Hooggayga weeyoo

Hiyiga iyo laabtaan

Kugu haynayaayoo

Weligay hoygaagaan 

Ka dul heesayaayoo

Hengel baan u xidhayaa

Inta haadka duushiyo

Idil habar dugaaggee

Ifka hibo ku noolow 

Aakhiro halkii roon '''
    ),
    GabayoModel(
      title: 'Amal',
      gabayga: '''
Dadku kala ayaan roon
Ama kala aqoon dheer
Ama kala asluub weyn
Hadaan eed la doonayn
Ama deeq Illaahay
Asaraar ka taagnayn
Dadku eexo kaa gelin
Inan yahay la'aantaa
Dumar lama abuureen
Gabadh lama ammaaneen
Jacayl looma ooyeen

Geed beer udgoon iyo
Ku dhex-yaal ugbaadoo
Ubax iyo man fuulaay
Ulihii madheedhkee
Iimey ku yaalliyo
Ilo wada xareedoo
Nafta lagu illaawaay
Dayaxoo iftiimoo
Arladoo dhan gadhoo
Afar iyo tobnaadaay

Qorraxdoo aroortii
Dhulka soo abbaartoo
Sagal iid dhex joogtaay
Waxaad tahay adduunyada
Dhexda udubka haystoo
Xejiyoo adkeeyoo
Af-gobaadsan maayoo
Qurux lama amaahdee
Ashkir geenyo ugubey

Adhaxdiyo laf-dhabartiyo
Sanbabbada agtoodiyo
Ililaha halbowlaha
Eebaa ku mudanoo
Arrintii cuslaatoo
Naftu aammusnaantii
Iimaansan weydoo

Amaleey jacaylkii
Soo dhaafyey uurkoo
Afku haysan waayoo
Goortaan ogaadee
Arammidu dillaacdaan
Ooddii ka leexshee

Axdi jaba abaal luma
Kaa eegi maayee
Igadh iyo maqaarkeed
 Innagoo ahaannaan
 Hadalkii ku ururshee
Adiguna dheh aammiin


'''
    ),
    GabayoModel(
      
      title: 'Baladwey',
      gabayga: '''
Bi'i waa jacaylow
  Boodhari inuu diley
  Been baan u haystee

  Bi'i waa jacaylow
  Boog aan la dhayinoo
  Cidi baanan karino
  Beerkiyo wadnaa iyo
  Bogga kaaga taalliyo
  Inuu yahay bir caashaqu
  Been baan u haystee

  Webigoo butaacoo
  Beeraha waraabshoo
  Dhulka baadku jiifoo
  Dhirta ubaxu buuxshoo
  Canabkii bislaadoo
  Badarkiyo galleydii
  Laga tuuray baalkoo
  Bulladiyo ciyaaraha
  Lagu waa bariistoo
  Beeluhu gu' joogaan
  Sow beri-samaadkii
  Beled Weyne maan tegin

  Dhanka bari magaalada
  Sow boqorad joogtoo
  Biyo dahab la moodoo
  Cilicdii haweenkiyo
  Bili loo dhameeyoo
  Timo boqonta joogoo
  Baal gorey la moodoo
  Baarkana casaankii
  Bidix midig is gaadhoo
  Bul-cad lagu xiddeeyoo
  Badh ku xeexanaysoo
  Barkanaysa qaaroo
  Huwanaysa baaloo
  Igu beertay lahashoon
  U buseelay maan baran

  Sow goor barqa ahoo
  Bishu ay siddeed tahay
  Aniga iyo Beer luli
  Isku maannu soo bixin

  Sow bariidadaydii
  Iyo bedashadeedii
  Buundada ciyaartee
  Beled Weyn ku taallee
  Biyo lulata guudkood
  Badhtankeeda maahayn

  Sow bixiso weeyee
  Ballan maanu dhiganoo
  Beeri joog imay odhan

  Sow bayd go'aygii
  Layguma bushaareyn
  "maantaa la baxayaa
  bulshadii imay odhan"

  Sow waa bastey oo
  Socod beegsan maayee
  Ina baaja caawoo
  I baxnaansha maan odhan

  Sow taliye baasoo
  Ba'anoo war-moogii
  Taydii ma beenayn

  Sow badiba kooxdii
  Goortay badheedhee
  Baabuurki fuulleen
  Anna baal kamaan korin

  Boholyow daraaddii
  Sow baraq nuglaantii
  Belo lagu ducaystiyo
  Baryo kumaan maqnaynoo
  "Biri may xumaatoo
  batroolka daadshoo
  ka wadaa bukoodoo
  bogsan waayo" maan odhan

  Sow beriga waagiyo
  Barqo kulul dhexdoodii
  Geed baaxad weynoo
  Dherer iyo ballaadh-loo
  La yidhaahdo Baaroo
  Bilig dheer hirkiisii
  Ma bidhaan sanaynoo
  Bulxankiisa yeedhiyo
  Ma maqlaynin baaqii

  Sow baaxad soorii
  Iyo laba boglayntii
  Maan noqon bestey oo
  Bacadkii ma dheelliman

  Sow galab-baqoolkii
  Annagoo barwaaqiyo
  Meel baadle joognoo
  Tumanayna Beerrey
  Sow maan baraarugin

  Riyo beena weeyee
  Sow baalla daymii
  Baabuur lalaahyood
  Haad baalle mooddoo
  Fananaaya buur dheer
  Isma odhan ka boodoo
  Nafta sow ma biimayn

  Nin Banaadir joogoo
  Beled-Weyn la haystoo
  Waxaan ahay la baabee
  Sow baadi doonkii
  Weli baafi maan ihi

  Beled-Weyn Allahayow
  Ka dhig xiro badhaadheed

  Beerlula Allahayow
  Belaayada hareer mari

  Beled-Weyn Allahayow
  Ka dhig guri barwaaqeed

  Beerlula Allahayow
  Beryo samo ku noolee

  Beled-Weyn Allahayow
  Ka dhig beerta raaxada

  Beerlula Allahayow
  Ka barii wax yeellada.

'''
    ),
    GabayoModel(
      title: 'God Madow',
      gabayga: '''

Gooyeen heddiisoo
Ragna garabsi moodkood
Ka gaboobi maayee
Gunburreyda hoosaan
Gurrac uga jarmaadoo
Darantiyo gulaankaan
Gebagebo ku dhaafoo
Guban xeebaheedaan
Sii maalin gaaloo
Qorraxdoo godkeedii
La gelaysa fooddaa
Luguhu I gabeenoon
Socodkii gadaashoo
Gerriyaad dhexdiisaa
Gudcur igu ballaadhoo
Garan waa kaskaygii
Geesaan u jeedoo
Gabaddano naf joogtaa
Gogol doonimaysee
Dhaxantaan go'aygii
Garbaha iska saaroo
Good iyo abeesaa
Igu soo gurguurtoo

Gool qawdhamaysaan
gondaheeda seexdoo
naftu guure mooyee
gama yeeliweydoo
guntigaan adkayston
marada isku giijoo
waaygoo duduutaan
goodiga abbaaroon
eeyi laga hayaamiyo
guri madhan is taagoo
sida goraya cawshoo
galab hoos u jeeddoo
gu'barwaaqadiisio

gaaroodi joogtoo
baydiri gantaaliii
geed ugula dhuuntoo
ku gilgiley falladhoo
meel halis ah gooyaa
gucle iga dhammaadoo
godollaan ordaayon
sida awr gabrareed
geeddiga higsanayo

gobolkaan u jeedaa
guulluhu I keenoo
gabayoox duleedkaan
weheshadey go'aygoo
anigoo gandoodoo
is-guhaadinaayaa
waxaan geystey mooyee
birta layla gaadoo
inantaan gardaadsheen
gaadiid sidiisii
ku xambaaray guudkaa
wedka ii guddoontee.

Godob-reeb ha joogee
Lay diid garawshoo
Giddi habar-dugaag baa
Waydaydu gaadhoo
Gorgorka iyio haadaa
Ilmo gabax ka siiyoo
Garanuugta aydaa
Geedaha ka soontoo
Ma hallayn gartaydee
Gacal baan u waayoo
Golahay lahayd iyo
Geedkeeda keenee
Guddidaan u dhiibee

Guudkeed xil-saaraa
I gargaari weydoo
Gaaliyo Islaamkaan
Gacan-siin ka waayoo
God madow dhexdiisaan
Ku gunaanad seegaa
Geeraarku joogaa

'''
    ),
    GabayoModel(
      title: 'Anuun baa hooyadaa ah',
      gabayga: '''

Hunguri calafbaa xukuma
Hantina dhaqanbaa shushuba
Dadkana hiddihiisa guud
Wixii la hayaa dhexyaal

Xaq iyo u-hal-buuxintiisa
Habboonkiyo waalid tiisa
Hilbiyo ku-arooridooda
Siduu uga hawl yaraysto
Halmaan laga yeeli maayo
Hawiyo tumashoy dhashayda
Ka daa gacan-haadiskaaga

Barbaar hanaqaad ku leexday
Duciyo habaar qaadan waayey
Cir iyo heeguu noqdaa
Hadhaysa dhul aan aqoone
Hoygii madhan wiilashiisa
Haween dumar baa ka sheegta
Hablaha kacaybaa u yeedha
Haldhaa jecel baa u qaybsan

Inaan hadlo maan sugaynin
Baxnaanana maan horjoogsan
Hubsiinana maan illaawin
Hoggeediyo xaajadayda
Dareenka haloosigiisa
Hugiisa inaan ka qaado
Hayaanka fogaaday baa leh
Markaan cidla hiil ka waayey
Naftayda halaanhalkeeda
Waxaan huri waayey sheego

Haantii lulatay dhegayso
Hoobaanta agtaada taalla
Hadiinadu baadi weeye
Hashii korisaa u ciillan

Qofaad halab-saariddiisa
Daryeelka horseedadiisa
Dedaallada heensihiisa
Habeenna ka seexan weydey
Ku meel maray heegantaada
Markuu hagar kuu banneeyo
Dharaar ku haleeli waayo
Hortaada waxaa yimaadda
Sidaad ugu heellanayde
Harraad iyo waa kalkiise
Hillaac baxayow dhegayso
Siday talo kaaga hoostay

Calooshu intay ku hoysey
Hiyigu ku baxnaaninaayey
Horraadka intaad jaqsiisay
Dhabtaydu intay ku haysey
Intaad huwanayd taftayda
Hobeeya hobey hobeyda
Intaan dusha kuugu heesay
Intaan hanad kuugu yeedhay
Hawraaraha kugu ammaanay
Intaan hubin kuu xambaaray
Dartaa u hoggaansanaaday
Hadhuubada aan ku siiyey
Habniin adigoo ku diidey
Intaan hambo kuu daboolay
Hammuun iyo gaajo qaatay
Adoo haqab-beel ku seexday
Intaan hurdo kuu illaaway
Ilaashay hareerahaaga
Hungaa i xasuusinaysa
Hayaydana meel shishaa leh
Hiloga naftaa aloosan
Kashaa hinqanaysa goorba'an
Hankaa i waraysanaaya
Tolow hebel mee ku foogan
Aniyo hirashaa is weyney
Higsiga noloshaa adkaaday
Adduun iyo haybsigiisa
Hangool li'idaan ku daayey
Waxaan ku hagaagi waayey
Dhankaad ku hagaagsanayde
Adoo ka hanweyn xaggayga
Qof kuugu hanweyn dantiisa
Cid aad ku hallaysay mooyi!

Halyeynnimadaada sheelan
Habawgiyo dhiirintiisa
Ayaan halis kuu tusayne
Intaan kugu hawlo-daaley
Intaan kugu hoodo-sheegtay

Intaan hebla' kuugu faanay
Hilaado fog bay lahayde
Inaan hafarkaaga qaato
Sidaad ku heshaa da' weyne
Adiyo habigaaga mooyi!

Habaaska inaad cantuugto
Adoo hanadaan ka dooratay
Xaggayga hibaan ku saaray
Anigu ku habaari maayo
Huqbaase ku raadinaysa
Hibaaq xalan maad ahayne
Hufnaanta dhibtii abuurtay
Inaanay hadhayn yiqiinso!

Hawaala adduun rabbaa og
Dadkuna kala hoodo weeye
Haddeer iyo tii haddeer
Hadhow iyo tii hadhow
Hoosiyo sare tii ku raacda
Anuunbaa hooyadaaya.
'''
    ),
    GabayoModel(
      title: 'Hud Hud',
      gabayga: '''
Boqorkay huq iyo ciil
Hagardaamo lumisow
Hadimada kalgacalka leh
Cilmigii u hoydow
Heesaha baroorta ah
Halqabsiga jacaylkow
Hambalyiyo salaan iyo
Hibo iga guddoomoo

Kolley waan hubaayoo
Hawlihii addunyada
Heshay aayahoodee
Hal yar aan ku toydee
Jannadii ma hurudaa?
Hadh qabow ma jiiftaa?
Hoobaan ma gurataa?
Hablo Xuural-caynii
Sow kuuma heesaan?
Waxa aad la haysaba
Hoo kuma yidhaahdeen?

Wedka lama huraayee
Reer soo hayaamiyo
Hayin raran ma kulanteen?
Hor Illaahay adigiyo
Hodan maysku aragteen?
Ma is dhaafsateen hadal?

Bal maxaan haweenkiyo
Dumar ugu hilloobaa?
Ama kula heshiiyaa
Ugu hagar la'aadaa?
Sowtay hir beeniyo
Ku tuseen hillaacee
Hogol aan da'ayn iyo
Hanfi kuu aroorsheen
Hirwo kuu garaaceen
Hungo kuugu baaqeen!

Sowtay ku hawleen
Ku jareen halbowlaha
Haadaan ku koriyeen
Hore kuugu riixeen
Hogga kuu dabooleen
Hoos kuugu tuureen!

Sowtay ku heereen
Hengelaa ku saareen
Gudcur kuu hillaabeen
Ku dhigeen habaaskee
Cidla kaaga hoyden
Hororkiyo waraabuhu
Hilbahaaga jiiteen
Haadda iyo xuunshadu
Hanbadooda feenteen!

Waxaan ugu hamranayaa
Hooyaa ka dhalatoo
Naaskii habreed baa
Iga hiilinaayee
Wallee hawlahaan galo
Iyo heegantaan dhigo
Dumar lama haweysteen
Ragba ma hungureeyeen
Hanti lagama dhiibeen
Guri laguma hoysteen
Hadal lalama yeesheen!


'''
    ),
    GabayoModel(
      title: 'Xamareey ma nabad baa',
      gabayga: '''
Xayaabkii cir da'ayeey
Daruur shalka xayddaay
Xulad geenyo ugubeey
Darmaan xoosh u dhalataay
Xil-dhibaanka nabaddaay
Xajkii Geeska Bariyeey
Cadceeddoo xab-bururtaay
Marna xabag barsheeddii
Nafta xiisa gelisaay

Xudduntii dhulkaygaay
Xaruntii dadkaygaay
Xamareey ma nabad baa?

Xiddigtii bahdeediyo
Xubnaheeda kala maqan
U ahayd xusuustee
Sumaddooda xaynkiyo
Shanta gees u xidhataay.

Xudduntii dhulkaygaay
Xaruntii dadkaygaay
Xamareey ma nabad baa?

Laamaha xorriyaddiyo
Xayn-daabka calankee
Xejinaaya dhalashada
Xididkay ka beermaan
Xinjir laga waraabshaay.

Xudduntii dhulkaygaay
Xaruntii dadkaygaay
Xamareey ma nabad baa?

Carra-edeg xanteediyo
Xaska weli dhex-yaalliyo
Xaskulaha in laga guro
Danahooda xigashiyo
Xagal-daac in laga jiro
Tii loo xil-saaraay.

Xudduntii dhulkaygaay
Xaruntii dadkaygaay
Xamareey ma nabad baa?

Isticmaarku xeel iyo
Xanaf iyo wax-yeelliyo
Xanan iyo dhibaatiyo
Xadhko miidhan weeyoo
Sida geed xajiinluu
Xagxagtaa kor kaagee
Xadantada gumeystaha
Xaram lagaga maydhaay

Xudduntii dhulkaygaay
Xaruntii dadkaygaay
Xamareey ma nabad baa?

Danta inay xaraashaan
Dembi inay xambaartaan
Ama sharafka xooraan
Isticmaar la xididaan
Ama xeer la yeeshaan
Nimankii ka xila-furay,
Naftu waxay u xilataa
Dhegta xeerinteedee,
Nolol aan xarrago wadan
Nimankii xanuunkiyo
Xabsiyada ka door-biday
Gobannimo xaq weeyee
Inta geesi loo xidhay
Ama xawda laga jaray
Geerida xalaasha ah
Nimankii xantoobsaday
Halka lagu xormeeyaay

Xudduntii dhulkaygaay
Xaruntii dadkaygaay
Xamareey ma nabad baa?

Shinnida Xumbaaliyo
Sida xaydha-weyntii
Nimankay Xawaashiyo
Xaab-qaaddu keentee
Xagga sare ka soo degey
Dhulka xaabadii tiil
Nimankii xambaartee
Dhirta xaalufka u rogey
Dunidaan is-ximinnoo
Xasillooni loo yaal
Dadku kala xishoodaan
Nimankii xaduurkiyo
Xadaafiirta geliyee
Inta ay xifaaliyo
Xumo iyo colaad iyo
Xiisadaa ku kiciyeen
Xolad daba ku olosheen
Xadhkaheeda kala furay
Xidid iyo tol wada yaal
Nimankii hub xoogliyo
Xakamaha ku kala raray
Kala xaday walaalaha
Marwadii xanjeerrayd
Nimankii xabbaadhee
Xawawaray dhasheedii
Kuwa midabka ximiyee
Xaqlahana addoonsada
Xistigiyo gumeystaha
Birta looga xiiriyo
Halka lagu xabaalay

Xudduntii dhulkaygaay
Xaruntii dadkaygaay
Xamareey ma nabad baa?

Sida xuur wedkeedii
Xan ahaa ku maqashaan
Amba xiisahaagii
Xamarey la dhuubtoo
Xalay waxan baraarugey
Iyadoo xiddayseey
Inta xaysku kuu da'ay
Dhulku wada xareed iyo
Xamash iyo ugbaad iyo
Xilli yahay barwaaqoo
Dayaxaagu xaynkiyo
Xuubkii dillaacshoo
Inta uu xanjaadkiyo
Xagal qudha la soo baxay
Dusha sare xinnaystoo
Dhallinyaro xariiriyo
Halbo Xuural-caynii
Isasoo xusheenoo
Xeebtaada yaabka leh
Inta ay xaraaraha
Laba laba u xaadheen
Xusullada dhigteenoo
Xeerkii kal-gacalkiyo
Lagu jiro xisaaboo
Xantu hoos u socotoon
Aniguna Xayaad iyo
Xiddigtii jacaylkee
Shanta xaraf mid lagu daray
Xog-waraysanaayoon
Kolba xaada cududdiyo
Xaradhkiyo garaaraha
Il-badhkeed ku xadayee

Xudduntii dhulkaygaay
Xaruntii dadkaygaay
Maxaad aniga oo xidhan
Lahashada xanuunka leh
Ii xusuusinaysaa?
'''
    ),
    GabayoModel(
      title: 'Daryeel',
      gabayga: '''
 Markaan daafta hoosiyo
	arko daymo-bogashada
	ararha la daadshiyo
	dhirta lagu daleeyiyo
	waxa buuro daah wayn
	lagu daabay ciidiyo
	bado laba dibleeyaa
	ishu damac i gelisaa.

	Markaan daawashada guud
	dayixiyo cadceediyo
	dildilaanka fadadkiyo
	onkodkiyo dayaankiyo
	danab laba dhacaayiyo
	dardaraa hilaaciyo
	arko hogol darroortaa
	runtu igu duxdaayoo
	derejada Ilaahay
	dib usoo xasuustaa.

	Haddaan doogga cawskiyo
	deegaantu saarayn
	dhulku duug ma yeesheen
	dihaal mareebeen
	qofna kuma daneysteen
	Rabiyow dushiisoo,
	dunidaada eebow
	adigoon cid dirranbaad
	todobaad ku dadabtoo
	iyaddoo dambarisoo
	sida doonan gabadheed
	inta timaha loo dabey
	dunta lugu afmeershaa
	laga furey daboolkoo
	dalagkaad ku beertaa
	ninba weel darsanayaa.

	Inkastuu qof diintiyo
	dar illaahey jecel yahey
	labadaan af yeeshaa
	koley waa dambaabaa
	hadduu kaa abaal daro
	dadka kaad u roon-tahey
	adigaa dul qaatee,
	Rabiyow hanugu dumin
	cirka duudka weynoo,
	Rabiyow aannu nala degin
	dhulkan aanu daaqnaa,
	Rabiyow hannugu didin
	bahalaha derderanoo,
	Rabiyow hanugu dirin
	dabeylaha cartamayoo,
	Rabiyow hanugu dirin
	duufanadaadoo,
	Rabiyow hanugu darrin
	durdurada rogmanayoo
	Daad xoor hanaga dhigin.

	Rabow duunyo nool baan
	ka awoow dugsanayoo
	dibnaheygu caaniyo
	dux baruurleh mooyee
	uma baran wax doorshee,
	Rabiyoow diraaciyo
	jiilaal dab-kululoo
	dibad joogta cowshiyo
	dabar gooya xoolaha
	Dibirtooda naga hay
	Raboow roobka deyrtiyo
	guga doogsintiisiyo
	Dirirada xareedaa
	dacalada hanaga marinee.

	Rabow duumadaadiyo
	inta cuduro duushee
	Docwareenka feedhaha,
	sambadada dalooshiyo
	Dacuun hanugu ridin.

	Rabiyow dagaaliyo
	dabley gaatamaysiyo
	doofaarro badan baa
	musduleedka joogee
	kuwa diidey nabadiyo
	belo laga ducaystiyo
	manaxaan hanoo dagin
	duulaan hanagu jebin.

	Rabow dowladnimaduna
	kuma iman dalxiisoo
	doorroonayaal baa
	u daldaley naftoodoo
	dumar baa hugoodiyo
	dahabkii u iibshoo
	Doondoonisteedii
	dhiig baa ku daatee,
	Rabow dawlad curatoo
	ubadkeeda deeqdoo
	dakhrada bogsiisiyo
	dawa la isku baantiyo
	ka dhig malabka doocaan.

	Rabiyow dirkeygii
	gobolaa dambeeyoo
	u dib jirey caddaawoo
	darrayada gumeystuhu
	daran-doori lagu dayey
	rabiyow ka soo daa
	Dibin-daabyadoodoo
	shanta dagal isu keen.

	Rabiyo dadkaygana
	danwadaag isjeceloo
	darjaysa qarankiyo
	bulsho laga dabqaatoo
	Carro Edeg ku dayatiyo
	ka dhig ul iyo diirkeed.

	Rabiyow dugaalkiyo
	dugsi waa dhul hooyee
	dibad ruux u sahan tegey
	duli waayi maayee!!
	nin da'diisa tuugoo
	dawarsadey asaagii
	doqoniimo weeyee!
	dalkayaga Ilaahow
	dheregiyo daryeel iyo
	Wax nadeeqa nagu sii.

	Rabow doodda akhiro
	marka ay durbaankiyo
	dawanadu is dhaafaan
	dadku kuu yimaadaan
	deryka soo fadhiistaan
	rabiyow hanagu darin
	inta aad ku digatee
	u dareerta Naartoo
	labadaada daraarood
	rabiyow ta door roon
	Kuwa dagaya naga yeel
	Amiin Allahayow
	Amiin Allahayow!!!
'''
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Container(child: Text('Gabayadii Hadraawi',style: TextStyle(fontSize: 20,color: Colors.white),)),
        backgroundColor: Color.fromARGB(255, 108, 232, 249),
        elevation: 0,
      ),
    body: ListView.builder(
            itemCount: gb.length, 
            itemBuilder: (context, index) => gabayo(
              gab: gb[index],
              ),)
    );
  }
}

class gabayo extends StatelessWidget {
  const gabayo({
    Key? key, required this.gab,
  }) : super(key: key);
final GabayoModel gab;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => Detail(gab: gab),));
      },
      child: Container(
       height: 80,
       width: double.infinity,
       padding: EdgeInsets.only(left: 20,top: 20),
       margin: EdgeInsets.only(top: 10),
       decoration: BoxDecoration(
         color: Colors.white,
         borderRadius: BorderRadius.circular(15)
       ),
       child: Text(gab.title??'',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
      ),
    );
  }
}








class Detail extends StatelessWidget {
  const Detail({Key? key, required this.gab}) : super(key: key);
final GabayoModel gab;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Container(child: Text(gab.title??'',style: TextStyle(fontSize: 20,color: Colors.white),)),
        backgroundColor: Color.fromARGB(255, 108, 232, 249),
        elevation: 0,
      ),
      body: ListView(
        children: [
          Container(
            margin: EdgeInsets.only(top: 35,left: 35,right: 20),
            
            width: double.infinity,
            
            child: Text(gab.gabayga??'',
            style: TextStyle(fontSize: 20,fontWeight: FontWeight.w400,),),
          )
        ],
      ),

    );
  }
}