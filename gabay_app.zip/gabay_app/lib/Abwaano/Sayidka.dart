import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:gabay_app/GabayoModel.dart';

class sayidka extends StatelessWidget {
   sayidka({Key? key}) : super(key: key);
  List<GabayoModel> gb=[
    GabayoModel(
      title: 'Xiin Faniin',
      gabayga: '''
Xayow Faaraxow1 hadal rag waa, loo xutubiyaaye

Nin xishood leh baan ahay haddaan, lay xistiyahayne

Xabiib baan ahaa jeer kufriga, laygu xaasidaye

Adna xaashi baad iila timid, xaakin soo diraye

Xaddigii adduunyada, haddaad xoola iga dooni

Marna anigu kaama xistiyeen, xaalaad leedahaye

Inaan kuu xaf gooyaan jeclaa, geel xawaar badane

Kumanyaal xawaadaan lahaa, xawd u sii mariye

Markaad Xiin Finiin2 damacday baan, kaa xanuunsadaye

Walaalow xirgiga qaarkii waa, lagu xujoobaaye

Waxaan kugu xutubiyaaba waa, xuuradaan nahaye

Nin kalaan xafiidaba adaan, xaaydda kaa rogaye

Xigto iyo qaraabiyo hadduu, xidid i weydiisto

Xayow iyo Qayumay haddii, la igu xoodaansho

Xubbigayga kuma hayn inaan, xiisoow bixiyaaye

Xamar weeye oo midab fardood, kala xiriir roone

Xawaariyo kabtiyo raaxo iyo, xawli iyo jeefag

Xaggii loo eryaba waa, gammaan xulashadiisiye

Xubno toosanlow neefku waa, xaalad gooniya e

Goortaan xusuus ula noqdaa, xiiso ii qabane

Waxaan xarafka diimeed ahayn, igaga xeel dheere

Xarbaddiyo jihaadkaan lahaa, xoogsi ugu fuule

Usagaan xatooyada lahaa, xuurta ugu looge

Xiniinyaha ku goo baan lahaa, gaalka xaylka lehe

Xayskaa da’ayaan lahaa, Xalin ka doodeeye

Xaqaygii maqnaa baan lahaa, xag ugu raacdeeye

Meesha iyo xeebtaan lahaa, xiito ka eryoode

Xujeeyreebta reer Hagar anaan, xubashyadii ruubin

Xinjoortoda dhiigga leh haddaan, lagu xaraaraysan

Xaqaamaquuqiyo haddaan, xaaluf lagu yeelin

Xiddaysane ma dhiibeen anaan, xaaladday bogane

Xaaraami uun baa arlada, xula abiidkiise

Wuxuun bay xushleeyaan sidii, xabashi Iiddoore

Aniguna xogtaydaan ka baqi, inay xumeeyaane

Xaashaallillaahive nin goba, xamasho waw ceebe

Goorteer anoo xaajiyaan, xinif awoodayne

lntii aniga lay xaman lahaa, xil iga soo meerye

Aduu galabta kuu xoolo yahay, xamarkii dheeraaye

Waa Xiin Finiin neefka aad, xarigga haysaaye

Xayawaanka oo idil naftay, kala xeraadaane

Mar hadduu suldaan3 igu xil lihi, igaga xayddaantay

Xariggiisa qabo aadmi kale, kuma xurmeeyeene.
 '''
    ),
    GabayoModel(
      title: 'Sow ma ha',
      gabayga: '''
Nin Ilaah yaqaan oo sharciga, ku isticmaalaaya
Ashahaado loo qoray nimaan, kala illaaweynin
Oo aan inkirihayn xaq waa, la oggolaadaaye

Nin salaadda awqaadda, faral u addimoonaaya
Oo dagada oofinahayoo, ugubka dhiibaaya
Oo aan afurin soonku, waa bilaha iideedee

Adduunyadiyo xoolaha ninkii, aragti dhiibaaya
Oo inuu ohay yiraah, ka istixyoonaaya
Oo aan bakhaylnimo abkiis, lagu ishaareynin

Nimaan diinta aafo u galayn, aakhiruu sabanka
Oo aan amxaarada sidii, obo u yaaceynin
Oo gaalka ooradu ku taal, u askareynin

Nimaan abuurka Soomaaliyeed, ka anfi taageynin
Oo aan ajuurada kufriga, ugu adeegeynin
Oo aan ardiga beesadeed, u ashtakoonaynin

Nin jihaad ohoominahayoo, ubaxa loo saaray
Ingiriiska eyga ah ninkii, ugu uneexaaya
Oo libin ajri leh soo heloo, or iyo geeraar leh

Nimanyahow aqoonxumadu, waa ardaalnimo e
Asaraar ma fiicnee, runbaa lagu arooraaye
Ninkii aynigaa lagu yaqaan, aw islaan ma aha?

Shir aguugay waayeel abyamay, talo ashaaddowday
Irda jiqa albaabo isku xiran, eel la bixin waayay
Xaajadaas afraha duubatee, loo olmami waayay

Nin aqoon leh aw iyo haddii, odaya loo saaro
Inkastoo ayaan iyo ayaan, lagu oloollaado
Ninkii maalitaa ka arrinshaa, aaqil aw ma aha?

Wiiwiida qaylada haddii, uubatadu yeedho
Sangootida ilwaadda leh haddii, agabka loo qaato
Awaaraha buska leh maalintuu, Xamar abraaraayo

Maantii warmaha oofta iyo, adhaxda lays gooyo
Maantuu aboodigu ku lalo, ubaxa loo daadshay
Maantuu isaayuhu ka dhaco, idil dagaalkeeda

Maantii fuluu naga ordo, alaba soo rooro
Maantii raggaan loo ilayn, naga ugaaroobo
Maantaa ninkii aarsan sow, aarka dhacay ma aha?

Nimaan edabdarroonayn xil, waa laga ajoodaayee
Aflagaadda aan jirin, nimaan kuula imaanaynin
Oo kaa asluubanahayoo, kaa istixyoonaaya

Ab uu yahayba aadniga ninkii, same ekeynaaya
Abtirsiinya kii xigay nimaam, iniq u dheereynin
Addoomaha Ilaahay nimaan, kala irdheyneynin

Ninkii aammusoo shib ah haddii, erey xun loo geysto
Aan kula ekeekamin intuu, urur ku soo joojo
Aan xaajo awgeed la gubay, ubucda jeexaynin

Anfaaciga adduunyada nimaan, ku anfariiraynin
Oo xeeryo soor lagu akhatimay, ibir ka yeelaynin
Oo sida ardaal wax u cunee, alam ka siineynin

Intuu aqalka baanjiyoo, nimaan aradda guuguulin
Aagaanta ciirta nimaan, aaska dhigaynin
Oo aan qumbaha awdinoo, ilaxirkow jiidan

Aaqibadii loo galo nimaan, kala illaaweynin
Oo kuu ixsaan fali intuu, edge adduun joogo
Oo aan abaaldhaca aqoon sow, akhiyaar ma aha?

Ari badan lo’ iyo geel intii, mulug adduunyaada
Ugub dhalaya qaalmaha umulee, laga unuun gooyey
Eeraan fardood iyo gammaan, aradka duulaaya

Aqal weyn aroos bilic leh oo, ilaxir loo yeelay
Inan quruxsan oo lagu ashbahay, uunsi iyo kheyli
Oo qool asliya loo gashoo, jalamtu eedaami

Nasteexiyo wanaag nikii, ilindi kuu keenay
Umuurtii aad leedahay ninkii, kuu abaynaaya
Adduunka iyo aakhiro ninkii, kuu aslaaxinaya

Ninkii maalinta iillaan tahay, aana kugu qaata
Oo aan abaarahakan dhacay, oodda kugu jiidin
Itaal xumana aan kaaga tegin, sow ikhwaan ma aha?

'''
    ),
    GabayoModel(
      
      title: 'Ismaaciil',
      gabayga: '''

Ismaaciil1 Mirow taladu waa, eyddin kaa maqane
Maandhow umuurtaadu waa, ababa’deediiye
Maandhow adduun wuxuu ahaan, waadan idihayne

Maandhow aqoonxumadu waa, ku ambineysaaye
Maandhow ninkaan edeb lahayn, waa Allow sahale
Maandhow aqliga ha iska lumin, Eebbahay magane

Maandhow raggii aakhiraad, igu ohomsiinee
Maandhow sidii ibilka way, ololinaysaaye
Maandhow waxaad igu akhriyi, uurkutaalada’e

Maandhow ikhwaanki ma deyn, urugadiisiiye
Maandhow alleylkii dhaxaan, alaladaaye
Maandhow ilmada ha iga qubin, kaa afeeftamaye

Maandhow nin umal saaqayoo, ururxun baan ahayee
Waxaan awlaaxu rabinayaa, aarsi dirireedee
Maandhow awaal dagatey baan, aawilahayaaye

Maandhow Ducaaliyo2 Ammaan3, waayey araggoode
Maandhow kuwii iga ajalay, waa rkaa bixiye
Aniguba ayaamaan lahaa, ha isallaaweene

Maandhow abaabaa kuu wadi, abadankeygiiye
Maandhow dadkaad eriday baan, ururinaayaaye
Maandhow ooho baan oron sidii, aaran baadiyahe

Maandhow intay iigu iman, odayadoodiiye
Maandhow iliilahakaney, awr ku soo furiye
Maandhow berry soo ekaan, ari sidiisiiye

Maandhow ixsaan lagama tago, eed haddaad faliye
Maandhow ninkaad iniqdo, waa ku oggolaadaaye
Maandhow haddaan inamo raro, way i aaminiye

Maandhow idday waxaan ku bogan, waa irdha la’aane
Maandhow ninkaan aa’i, waw aamusahayaaye
Aflagaaddadaadaan ka baqi, inay ogaadaane

Maandhow sidii aarka dhici, waw iigalaclayne
Maandhow ilaaq baan ku wadi, aarankaan diliye
Maandhow ku eersaday hadday, iga ufoodaane

Maandhow ugaadhaba xirkaa, laga agloolaaye
Maandhow urtaan mari sidii, adamaddoonkiiye
Maandhow arbaha ha iga didin, oofataan ahaye.

'''
    ),
    GabayoModel(
      title: 'Ogaadeen Baan Ahey',
      gabayga: '''


Aw Yuusufoow erey yar baan, ku erganaayaaye
Hadduu Eebbahay kuu idmaad, ururta weyn gaadho
Ikhwaanoow adkee xaajadaan, kugu ammaanaystey

Ku ansaxi halkii aan ku iri, aadna ugu fiirso
Gurraasiyo Iljeex iyo u sheeg, nimanka Iiddoora
Ogaadeen haddaan ahay dad wow, amar korreeyaaye

Oo ubaxa baarkaan ihiyo, awrta Haashima e
Abtirsiinydey waxay gashaa, odoyo waaweyne
Halkaan uga arooraana waa, odaga Daaroode

Rasuulkii udgoonaa waa, ina-adeerkay e
Sayidkii Axmed ahaana way, awow ruma e
Ibraahim-Rashiid1 aabbahay, odagi weeyaane

Asaxaabihii oo dhan baan, ehel waddagnaaye
Hadba anigu qoyskaan ahaa, loo irkanayaaye
Nin Amxaara mooyee intii, edge adduun joogta

Islaameedku wuxuu ii yaqaan, ehelu-kheyrkiiye
Aakhiro albaabbada jannaan, agabsanayaaye
Adiguna abbaanow midgaan, uraya saw miihid?
Saw kii Ilaahay necee, eyga qalay miihid?

Rabba Deeqa

Rabbaa deeq leh roobbaa qabow, raaxo nabad baa leh
Jannaa ruga raxmaan baa baryo leh, raacis Nebi baa leh
Werdaa ridis leh weli baa rilla leh, rabid shareecaa leh

Run baa fiican beenbaa rufucan, raran cadaab baa leh
Rataa xoog leh geel baa ruko leh, ramag haleelaa Ieh
Araa raxan leh reer baa raqsi leh, rogob wan weyn baa leh

Bad baa reen leh rays baa cunto leh, ruqa abaar leh
Goraa raan leh aar baa riddama, rooris faras baa leh

Jannaa udug leh jiic baa godgodan, jahanamaa qiiq leh
Jigraa ridis leh xoolaa Jigjiga, jooga anigaa leh
Wuxuu soo jibaadaba libaax, jees maraa mlcile

Allaa xoog leh diinbaa xarbl leh. tegid xajkii baa leh
Gobbaa xigid leh xoor baa dhanya leh, dhaqasho xiita leh
Xasad iyo xumaan laysku dilo, xiisad beled baa leh

Aqal xeerar wayn xaal gobeed, xilasho gaaraa leh
Xurmo iyo wanaag loo xishiyo, xidid galbeed baa leh
Waxaan kaa xishoon iyo ximaar, xeewal bari baa leh
Allaa weyn cirkaasaa wahdiya, waaya duni baa leh

Dayax iyo shamsada deyran baa, daalac iyo nuur leh.

Lo’ baa sixin leh ari baa sadaqo leh, xooryo ibil baa leh
Bir baa sulub leh soofaa wax jara, tamayo geed baa leh

Wax ciyoonba loo go’iyo … sumuc baa leh
Cashrigaa wax laga soo rogiyo, cagana Dhooddaa leh.

'''
    ),
    GabayoModel(
      title: 'Rabaa deqa',
      gabayga: '''
Rabbaa deeq leh roobbaa qabow, raaxo nabad baa leh
Jannaa ruga raxmaan baa baryo leh, raacis Nebi baa leh
Werdaa ridis leh weli baa rilla leh, rabid shareecaa leh

Run baa fiican beenbaa rufucan, raran cadaab baa leh
Rataa xoog leh geel baa ruko leh, ramag haleelaa Ieh
Araa raxan leh reer baa raqsi leh, rogob wan weyn baa leh

Bad baa reen leh rays baa cunto leh, ruqa abaar leh
Goraa raan leh aar baa riddama, rooris faras baa leh

Jannaa udug leh jiic baa godgodan, jahanamaa qiiq leh
Jigraa ridis leh xoolaa Jigjiga, jooga anigaa leh
Wuxuu soo jibaadaba libaax, jees maraa mlcile

Allaa xoog leh diinbaa xarbl leh. tegid xajkii baa leh
Gobbaa xigid leh xoor baa dhanya leh, dhaqasho xiita leh
Xasad iyo xumaan laysku dilo, xiisad beled baa leh

Aqal xeerar wayn xaal gobeed, xilasho gaaraa leh
Xurmo iyo wanaag loo xishiyo, xidid galbeed baa leh
Waxaan kaa xishoon iyo ximaar, xeewal bari baa leh
Allaa weyn cirkaasaa wahdiya, waaya duni baa leh

Dayax iyo shamsada deyran baa, daalac iyo nuur leh.

Lo’ baa sixin leh ari baa sadaqo leh, xooryo ibil baa leh
Bir baa sulub leh soofaa wax jara, tamayo geed baa leh

Wax ciyoonba loo go’iyo … sumuc baa leh
Cashrigaa wax laga soo rogiyo, cagana Dhooddaa leh. 
'''
    ),
    GabayoModel(
      title: 'Sayid baa',
      gabayga: '''
Geela siisahaygii arkee, Seeto1 laga cayrshay
Ee suudigii lagu eryiyo, soolka iyo hawdka
Oo Lebisagaalaad2 maree, Saaxil loo qaxiyey

Sayid baa ka baqay waa halaan, saabka galihayne
Nin waliba sinjigii waa tagaa, siiraduu yahaye
Alla hadalku saxariirsanaa, waa sab alabkeede

Waa sugurdhe Colujooga3 yiri, saajac baan ahaye
Saraakiil nin gowracahayuu, saa’ilahayaaye
Hadduu Sugulle Caynaanshe yahay, sidaa ma yeeleene

Wiilyahow salaafxumada waa, saymhoo kale e
Waa lagu sixraye kuma dhacdeen, surin ciryoone
Sirqayahay waxaad raadin waa, sababul mowdkiiye

Adigaa salaadsaday inaan, soofka kaa dhaco e
Waa saadsataye Ina-Jugloow4, silic ma joogteene
Saakana maxaad oran lahayd, saabir baad tahaye.


'''
    ),
    GabayoModel(
      title: 'Waayeel',
      gabayga: '''
Nuuroow1 ninkii dhimira laa, dhowrsadoo baqa e
Mar haddii u dhiirrado xil iyo, dheec Allaa badaye
Ma dheellimatay waayeel dhadhabay, waa dharrici weyne

Mar haddaanan dhiig idinka gelin, dhaqanna kaa qaadin
Oo aannaan hadal dhiifle iyo, dhaw xun idin taaran
Oo aannaan dhimin reer tolkaa, dhamamax mooyaane

Haddii aan dhaqaaliyo wanaag, kugu dhareynaayay
Oo aanan wax kuu dhimin, rag waa la iska dhowraaye
Dhaandhaan miyaa tahay maxaad, iigu dhabatowday?

Rag ninkaan dhurmuumiyaaba waa, dhararaqdiisiiye
Dhurwaaguba haddii uu hal dilo, waa dhayalayaaye
Dheregtiyo ladnaantii miyaad, igula dheelaastay?

Dhifku inuu ku qaban waa hubaa, adiyo dhowrkaaye!
Dhaqsaa Eebbahay kuugu ridi, dhaw aan kaa harine
Waa kuu dhuunkaal soor waxaad, dhugux ka siisaaye!

'''
    ),
    GabayoModel(
      title: 'Daraawiishl',
      gabayga: '''

Daraawiish gulfaasay, gabay baan ku sii fari
…, gudoodiga habeenkii
Goodkiyo abeesyada, waxba idinma gaaraan
Cudhii Dharrooreed1, mar haddaad gayootaan
Gabannada Cismaan2 dhalay, gabanna ha ka imannina
Matukade3 gardaadkiyo, gadhka iiga soo jara
Gadac4 iyo raggiisii, gowsaha ka soo gura
Gadhcas ivo gareentiyo, gunta Cali Jibraahiil
Gcel waxay lahaayeen, gacmahiinna buuxsada
Waxay guuyo haystaanna, gunta uga soo jara
Gumeysihii Cali, haydin daba gucleeyeen… 

'''
    ),
    GabayoModel(
      title: 'laaleys',
      gabayga: '''

Xuseenoow war laabuda haddaad, an iga laameeri
Waxa igu lillaahiya inaan, laayacaad ahaye
Laaleys siduu iiga lumay, luudis baan ahaye

Kob uun baan ku laabnahay, sidii liite doora lehe
Laafyaha waxaan baacin jirey, laabtay gacantiiye
Luuqyada haddaan mari, gabdhuhu igama leexdaane

Lar kacaan didayaa sidii, layli cararaaya
Lawaaxiga dharaareed cidlaan, layrsanahayaa
Lubbigeyga kaliyaa fadhiya, lebi dabeyl weyne

Qorrax liicday goortay shamsadu, libiqsatoo ciirto
Waxaan soo lug qaadaa markay, laxuhu ciiraane
Laankaan fariistaa sidii, layf martaaniya e

Waxay laabtu ii ruxan duqii. luqunta weynaaye
Isagaa kolkuu lumay qalbigu, ii lalabayaaye
Waxa labalegdaha ugu wacan, laaqanaan tebiye

Dagaaikaan ku laablaabi jirey, igu luggooyeene
Libaas kacaya loolima dagaal, leebi dirirteeda
Laqwina maayo maantay cirradu, laaca ii tahaye

Luggooyooyinkaan qabo Rabbaan, laxawga moogeyne
Ma liibanayaaloow kufray, lib u walwaaleene
Waxaan laabta ku hayaa inay, laqamma hcereene.
'''
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       backgroundColor: Colors.grey.shade100,
       
      appBar: AppBar(
        title: Container(child: Text('Gabayadii Sayidka',style: TextStyle(fontSize: 20,color: Colors.white),)),
        backgroundColor: Color.fromARGB(255, 108, 232, 249),
        elevation: 0,
      ),
    body: ListView.builder(
            itemCount: gb.length, 
            itemBuilder: (context, index) => gabayo(
              gab: gb[index],
              ),)
    );
  }
}

class gabayo extends StatelessWidget {
  const gabayo({
    Key? key, required this.gab,
  }) : super(key: key);
final GabayoModel gab;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => Detail(gab: gab),));
      },
      child: Container(
       height: 80,
       width: double.infinity,
       padding: EdgeInsets.only(left: 20,top: 20),
       margin: EdgeInsets.only(top: 10),
       decoration: BoxDecoration(
         color: Colors.white,
         borderRadius: BorderRadius.circular(15)
       ),
       child: Text(gab.title??'',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
      ),
    );
  }
}








class Detail extends StatelessWidget {
  const Detail({Key? key, required this.gab}) : super(key: key);
final GabayoModel gab;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Container(child: Text(gab.title??'',style: TextStyle(fontSize: 20,color: Colors.white),)),
        backgroundColor: Color.fromARGB(255, 108, 232, 249),
        elevation: 0,
      ),
      body: ListView(
        children: [
          Container(
            margin: EdgeInsets.only(top: 35,left: 35,right: 20),
            
            width: double.infinity,
            
            child: Text(gab.gabayga??'',
            style: TextStyle(fontSize: 20,fontWeight: FontWeight.w400,),),
          )
        ],
      ),

    );
  }
}