import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:gabay_app/GabayoModel.dart';

class Raage extends StatelessWidget {
   Raage({Key? key}) : super(key: key);
  List<GabayoModel> gb=[
    GabayoModel(
      title: 'Bi\'i waayey',
      gabayga: '''
Bus xaggaaya jiilaal balyaday, qaranka oo biifay
Barin doog leh nayluhu gugay, baqalyo rooraane
Baakiro tarkeed wow bishaa, laba bakuuroode
Bintadii lahayd dhaan hadday, uga buseylayso
Birisku biyaha ceel ma sido, mana baqool daayo
 
Baaluqe ismood wiil hadduu, buuryo-goys yahaye
Bisqinbaa nin weyn kugu dirtoon, biidna kuu tarine
Shansho iyo baruuriyo hadduu, badhi wan weyn yeesho
Baraar habartii loog kama baxshoo, gowrac kama baajo
 
Buulalaydh maraakiibta waa, lagu bidhaanshaaye
Intaan baxar sitiin kula galaan, kaaga soo bixiye
Badda hooy ka joog moolka, yaa bahalo jiifaane
Bi’i waaye Habar Yooniseey, baadidaa cesho
 '''
    ),
    GabayoModel(
      title: 'Garaad',
      gabayga: '''
Wiyil gaarin geeskiyo dhagtiyo, giirka qaban maayo
Shabeel oon gabraartiis ogahay, gacantogleyn maayo
Gojaxiyo nin waran ii watoo, ani i gaadaaya
Gag intaan idhaahdo oon hurdada, ugu garaardaayo
Garbahayga hilibkaa ku yaal, gooso odhan maayo
God abeeso gacantayda midig, galin aqoon maayo
Garaadkeygu meelaha badhkood, ani i geyn maayo
'''
    ),
    GabayoModel(
      
      title: 'Qubane',
      gabayga: '''

Illeyn caano way kala xidhmaan, dhayda iyo xoortu

Illeyn xabbagta geedaha ku taal, gabal xadhaadh weeye

Illeyn seeddigaa kuma xiltiro, xile haddaad weydo

Allahayow xadhaadhaa anfaco, xalayto la siiyey

Naa soo Xaliimoy Xaddiya, xaalna kama raacdid

Naa soo dharkaagoon xumayn, xidhan aqoon maysid

Naa soo tolkuba waa xurmee, kaba xishoon meysid

Naa soo dabkuba wuu xudhmaaye, xaabo lama saaro

Naa soo xalliin laguma dayo, xeedhadiyo weelka

Naa soo ardaageer xunka ah, waana lama xaadho
'''
    ),
    GabayoModel(
      title: 'Hami',
      gabayga: '''


Xalay Isniintii waxaa i helay toban umuuroode
 Asal gama'na ways idhi hurdana uurka kama seexan 
 Indhahana makala qaadihayn, aragna way muuqday
 
Afka kama dhawaaaqayn hadana, aamus ma aan yeelan 
Ogaan uma qoslayn oo hadana, iligyaday muuqday
Aradkana dad kuma weheshanayn, ururna waan joogay
 
Albaabada dibada baan ka iil, aqalna waan jiifay
Istanbuuli cadar layma marin, udugana waydaaray 
Oon baa idilay oo biyaan ku agwareegaayay
 
Onkod iyo hilaac roobna waa, nagu itaaleeyay
ufo dhibicdu may wadin hadana, ooduhuu lulayay
Awaartii manabin oo hadana, wuu anfacay kaynta
 
Anfariir xaluunbaan hurdada oog la sookacaye 
Ilinkaan talaabada ku waday, kol aabaarahaaye
Meeshaan abaarada kutago, aakhir bal aan eego
'''
    ),
    GabayoModel(
      title: 'Rabaa deqa',
      gabayga: '''

Sida koorta Yucub oo la sudhay, korommo buubaal ah
Ama geel ka reeb ah oo nirgaha, laga ka xaynaayo
Ama beelo keynaan ah, oo kor u hayaamaaya
Ama ceel karkaarrada jebshiyo, webi karaar dhaafay
Ama habar kurkii iyo wadnaha, lagaga kaw siiyay
Ama kaal danley qaybsatiyo, kur iyo dhal yaabis

Shinni kaaluf galay ama siddii, koronkoroo oomi
Xalay kololo’aygii ma ladin, kaamil reeruhuye
Kunbulkiyo ardaagii miyaa, laygu kaliyeeyay?
Wixii laygu kuunyeeyay miyaa, igu karaamoobay?
Kunbiskii miyaa layga qubay, kolayo ii buuxay?

Maantana kataantii miyaa, layga kala qaaday?
Kob abaar ah oo dhexe miyaa, koore ila meeray?
Kub miyaan ka jabay biixiyaan, kabayo loo haynin?
...

'''
    ),
    GabayoModel(
      title: 'Duusho',
      gabayga: '''
Dadkaan lumiyey, reerkaan dayacay, wiilashaan deyrshay
Iyo duusho siday naaga kale iigu dacaraysay
Iyo dawdarnimadaan ku kacay sida qof duul qaaday
Mindhaa labada daan iyo gacmaha siima kala daayo
…
Gabaygani ma dhamaystirna

'''
    ),
    GabayoModel(
      title: 'Sir waaqoon',
      gabayga: '''

Subxaanyaduba waa halaq hadday surin maraysaaye
Senti-taano waa lacag hadday saaran tahay miise
Saratoosiyuhu waa wax weyn waana haad suga e
Sambab waa cad weyn oo kuyaal sarara hoostoode
Sooxaari waa timir Barni yaysan saakumine
Siin iyo dhareer waa candhuuf waana shay si ahe
Siwaaqroonba waa niman hadday socoto Xaafuune
	
Subeer Maxamed, Siin Waaq, Bah Geri, Habar Siciid oo dhan
Saddexdii Harti iyo looma tegin Sade Mareexaane
Daarood silsiladiisa kore ayaan laysa soo sudhine
Saaxiibkayow ma anigaa suqayar lay mooday?
Mise wiilku wuu salal-anbaday Siiyahay magane?
....
Surgin baan ku jiriqsiin lahaa sidii sagaareede
Sanduuqbaan ku aabudhi lahaa soomadaaye ahe
Samo aabahaa falay baryaad sado ku maashaaye
Samaanteeda Habaryoonis baan salax rogaayaaye
Caku reer Suldaan Diiriye iyo Sugulle Caynaashe

'''
    ),
   
    
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Container(child: Text('Gabayadii Raage Usaag',style: TextStyle(fontSize: 20,color: Colors.white),)),
        backgroundColor: Color.fromARGB(255, 108, 232, 249),
        elevation: 0,
      ),
    body: ListView.builder(
            itemCount: gb.length, 
            itemBuilder: (context, index) => gabayo(
              gab: gb[index],
              ),)
    );
  }
}

class gabayo extends StatelessWidget {
  const gabayo({
    Key? key, required this.gab,
  }) : super(key: key);
final GabayoModel gab;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => Detail(gab: gab),));
      },
      child: Container(
       height: 80,
       width: double.infinity,
       padding: EdgeInsets.only(left: 20,top: 20),
       margin: EdgeInsets.only(top: 10),
       decoration: BoxDecoration(
         color: Colors.white,
         borderRadius: BorderRadius.circular(15)
       ),
       child: Text(gab.title??'',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
      ),
    );
  }
}








class Detail extends StatelessWidget {
  const Detail({Key? key, required this.gab}) : super(key: key);
final GabayoModel gab;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Container(child: Text(gab.title??'',style: TextStyle(fontSize: 20,color: Colors.white),)),
        backgroundColor: Color.fromARGB(255, 108, 232, 249),
        elevation: 0,
      ),
      body: ListView(
        children: [
          Container(
            margin: EdgeInsets.only(top: 35,left: 35,right: 20),
            
            width: double.infinity,
            
            child: Text(gab.gabayga??'',
            style: TextStyle(fontSize: 20,fontWeight: FontWeight.w400,),),
          )
        ],
      ),

    );
  }
}