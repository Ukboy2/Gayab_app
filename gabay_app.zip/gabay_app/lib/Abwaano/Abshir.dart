import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:gabay_app/GabayoModel.dart';

class Abshir extends StatelessWidget {
   Abshir({Key? key}) : super(key: key);
  List<GabayoModel> gb=[
    
  
    
    GabayoModel(
      title: 'Qaadow Adigaa Leh',
      gabayga: '''

Qorya raamso quudkana yaree qaadow adigaa leh
Boqolaal qorshoo wada qabya ah qaadow adigaa leh
Qoys dumaya qayliyo huruuf qaadow adigaa leh

Qalbi qooqan qoora aan waxtarin qaadow adigaa leh
Qardareeye kaadida qul quli qaadow adigaa leh
Jirkoo qaasha nadarkoo qayiran qaadow adigaa leh

Qalbi guban sigaar lagu qanciyo qaadow adigaa leh
Macdan qubta hawshoon laqaban qaadow adigaa leh
Hurda qarow ah soojeed qam qama qaadow adigaa leh

Iska qaado qaantana ha bixin qaadow adigaa leh
Qayil oo cun reerkiina qadi qaadow adigaa leh
Qashin iyo qashaabiir qurmuun qaadow adigaa leh

Qatar caafimaad oo qarsoon qaadow adigaa leh
Qalbi olol mar qabo oo qaniin qaadow adigaa leh
Qaraabo iyo ehel aan latabin qaadow adigaa leh

Qayrkaa shaxaad hana qajilin qaadow adigaa leh
Iska qari cidbaa kugu qabsane qaadow adigaa leh
Qabri ka hor qandha aan laga biskoon qaadow adigaa leh

Isqandiiri kana qoomamee qaadow adigaa leh
Ibliis qarowga aadmiga ku qaba qaadow adigaa leh
Afku wuxuusan ii qaban karayn qaadow adigaa leh

Qosol iyo qamuunyo isku xiga qaadow adigaa leh
Qasad dhaar ah qawl aan la fulin qaadow adigaa leh
Qur'aan lagu kaftamo qadaf iyo been qaadow adigaa leh

Cimri kuu qorraa qayb ka lumi qaadow adigaa leh
Qandiga fuqurka iyo quus rageed qaadow adigaa leh
Qureesh gabara waxa loo qawada qaadow adigaa leh

Dad qamaama qayliyo dagaal qaadow adigaa leh
Shaluu qaatay maantana qafaal qaadow adigaa leh
Qabyaalad iyo iimaan la'aan qaadow adigaa leh

Dhaliyara afkooduun u qoran qaadow adigaa leh
Wax ninwayni qaadoo qawada qaadow adigaa leh
Salaadaha dib qabo ama qallee qaadow adigaa leh

Xubna qaadiwaa sida qof qalan qaadow adigaa leh
Qabiltu jaanka aadmiga ku qabo qaadow adigaa leh
Dubaab lagu qarwoo kugu qulqula qaadow adigaa leh

Bisad ku quustay dabadeeda qabo qaadow adigaa leh
Qarjaf sayntu inay kuu tiraa qaadow adigaa leh
Qanaaskiyo was waaskaa qarsoon qaadow adigaa leh

Qandaraaska qaatumo xumada qaadow adigaa leh
Qarbaboosh ilkiyo gawsa qodan qaadow adigaa leh
Afqashuusha oon cadaygu qaban qaadow adigaa leh

Af qalala bushima qolof dhacsada qaadow adigaa leh
Qasban qayb daroogada ka mida qaadow adigaa leh
Qaflad aan dareenkeed la qabin qaadow adigaa leh

Ragoo quusta dumarkoo qawada qaadow adigaa leh
Faqiir qani ismoodoo qayila qaadow adigaa leh
Indha qoriya qaadirada subax qaadow adigaa leh

Qubays laga wahsado iyo qurmuun qaadow adigaa leh
Qamiis walaf quluub aan xasilin qaadow adigaa leh
Qoys laga dhixiyo qaaqla nimo qaadow adigaa leh

Waa quutul awliyo kidbiya qaadow adigaa leh
Qaamuuska waxa cay ku qoran qaadow adigaa leh
Inoo qaybi aan lagu qancayn qaadow adigaa leh

Qabsimadu inay kala xirmaan qaadow adigaa leh
Qurbaha joog adoon hawl ka qaban qaadow adigaa leh
Deg deg loo qasaariyo shilqoran qaadow adigaa leh

Qiso yaablohooy qarinayaan qaadow adigaa leh
Qofka daa'imoo qiima dhaca qaadow adigaa leh
Waxaad shalayto qabatoo qariban qaadow adigaa leh

Ku qasaar macaashkana ku qarow qaadow adigaa leh
Magnad kugu qasbiyo qaac ibliis qaadow adigaa leh
Hanti qaran qanaafiir ugee qaadow adigaa leh

Qaadicu salaadnimo asala qaadow adigaa leh
Intuu qadaf qof uun ku hadli karo qaadow adigaa leh
Lixdankaa qisoo wada qubxiya qaadow adigaa leh
Qaatala ka laahuye adigaa qaranka aafeeyay
'''
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Container(child: Text('Gabayadii Abshir bacadle',style: TextStyle(fontSize: 20,color: Colors.black),)),
        backgroundColor: Color.fromARGB(255, 108, 232, 249),
        elevation: 0,
      ),
    body: ListView.builder(
            itemCount: gb.length, 
            itemBuilder: (context, index) => gabayo(
              gab: gb[index],
              ),)
    );
  }
}

class gabayo extends StatelessWidget {
  const gabayo({
    Key? key, required this.gab,
  }) : super(key: key);
final GabayoModel gab;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => Detail(gab: gab),));
      },
      child: Container(
       height: 80,
       width: double.infinity,
       padding: EdgeInsets.only(left: 20,top: 20),
       margin: EdgeInsets.only(top: 10),
       decoration: BoxDecoration(
         color: Colors.white,
         borderRadius: BorderRadius.circular(15)
       ),
       child: Text(gab.title??'',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
      ),
    );
  }
}








class Detail extends StatelessWidget {
  const Detail({Key? key, required this.gab}) : super(key: key);
final GabayoModel gab;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Container(child: Text(gab.title??'',style: TextStyle(fontSize: 20,color: Colors.white),)),
        backgroundColor: Color.fromARGB(255, 108, 232, 249),
        elevation: 0,
      ),
      body: ListView(
        children: [
          Container(
            margin: EdgeInsets.only(top: 35,left: 35,right: 20),
            
            width: double.infinity,
            
            child: Text(gab.gabayga??'',
            style: TextStyle(fontSize: 20,fontWeight: FontWeight.w400,),),
          )
        ],
      ),

    );
  }
}