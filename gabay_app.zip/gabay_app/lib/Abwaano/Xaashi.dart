import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:gabay_app/GabayoModel.dart';

class Gaariye extends StatelessWidget {
   Gaariye({Key? key}) : super(key: key);
  List<GabayoModel> gb=[
    
   
    GabayoModel(
      title: 'Fad Galeed',
      gabayga: '''

   Gabbal-dhaca cadceed-yahay
   U sii faano-guratee
   Casar gaaban liiqii
   Godka weeraraysaa!
   Go'e fuley miyaad tahay?
   Waa maxay garmaamadu?

   Ma googooska sagalkiyo
   Gamasyada shucaacaa,
   Gaade kaa horreeyiyo
   Gurigaad ku hoyan layd
   War ku gubay ka soo direy?

   Mise gabadhan dhoolkiyo
   Gu'goo shaalka xaytiyo
   Fad galbeed la moodaa,
   Kolkaad gelin is-dhugateen
   Guluubkaagii shiikhoo
   Dib-u guradku waa baqe?

   Mise ganac-jabkaagiyo
   Waxaad galabta mudataad
   Intay goori goor tahay,
   Dayax soo lug-gu'i laa
   Sii war-geli is-leedahay?

   Gedgeddoonka hirarkee
   Iyagoo garaaro leh,
   Gaatin-socodka laafyaha
   Xarragada u gaarka ah
   Goonyahaaga tiiciyo,
   Gaardiga daruuraha
   Kugu gaaf-wareegee,
   Gumucaad ridaysiyo
   Goolli-baadh fallaadhaha,
   Shafka kaga garaacdee
   Isu rogay guduudkee,

   Dhiiggooda gobo'liyo
   Giirgiirka caadka leh,
   Ku sibbaaqday guudkiyo
   Gara-saar-dabtoodii
   Maxaa maanta gaasirey?
   Miyay kugu giriifeen?

   Mise waxay ka giigeen
   Gobaad haybaddeediyo,
   Gantaalaha jacaylkiyo
   Kalgacaylka beereey
   Indhaheedu ganayaan?

   Afartaa siddiri-gam
   Waxaan gocanayaa weli,

   Tiiyoo gareyskiyo
   Marta debec u gunuddoo
   Guranaysa hoobaan,
   Oo aan geyaankeed
   Geesaha ka filanayn,
   Dabayshii gadoodee
   Uurkayga garatee
   Gaadmada ku qaaddee,
   Gosha iyo horaadkiyo
   Gaaddada u faydiyo,
   Garba-duubka maraday
   Durba "geb" isku siisiyo,
   Gabbashada xishoodka ah
   Gorodday lulaysiyo
   Ugubnimo-gandoodkii

'''
    ),
    GabayoModel(
      title: 'Carshigii',
      gabayga: '''

  Ma cawaa ma caanaa?
	Ma cug baa ma cigashaa?
	Ma ciirsaa ma calaf baa?
	Ma cisaa ma culuq baa?
	Ma daruur gu' curatoo
	Cir-caddaadi noqon baa?

	Ma cigaalka feleggiyo
	Cir-jiidhkii Mariikh baa?
	Ma magool cusaybaa?
	Ma cadceed arooryoo
	Fallaadhaha casuusta leh,
	Ku cabsiisay dhedadoo
	Ceeryaanti didisaa?
	Ma xareed is-celisaa?

	Ma habeen cadda ahoo,
	Balliyada cigaagani
	Casuumeen xiddigahoo;
	Cirka dayaxi kaa jirey
	Dhulka kaa cawaray baa?

	Cosob rayska xaadhiyo
	Ma gargoorki Ceegoo
	Calcalyada barkaday baa?
	Alla samay cuddoonaa!
	Uduggaa carfoonaa!
	Samsam caynka loo dhigay
	Citibaaro badanaa!

	Callo maaha liiti ah;
	Habac maaha ceebo leh;
	Qallaf maaha camal ba'an;
	Coon maaha loo hoyan;
	Baali maaha caaryo leh;
	Cirir maaha toomama;

	Cawro maaha socod badan;
	Cayil maaha laga dido
	Caatana u may bixin.
	Cid kastaba u geeyoo
	Meel laga canaantiyo
	Cillad looma heli karo.

	Cabdiyoow tallaabada
	Cutiyaan idhaahdaa.
	Timahay cawayskii
	Cidhifyada u saartee,
	Ku cayaara laydhee
	Cawryaan haldhaayadu.

	Dibnaheeda culayga ah
	Cirridkeeda dhuxusha ah
	Ilkahaa caddaanka ah
	Naasaha cambuusha ah
	Sunnayaasha cawsha ah,
	Sanqaroorka caynab ah

	Dhexda caaro-dhuubta ah
	Mas-ciideedka midabka ah,
	Cududaha garaaraha
	Kubabkay u culus tahay,
	Cambarshaha surkeedeey
	Sirirsheen cabbaadhyadu,
	Waa xuural-caynoo
	Kolba anu tin iyo cidhib
	Cad aan quudho kuma arag.

	Cag-fudayd u may dhalan;
	Cadho laguma sheegayn;
	Waa canaadi lama odhan;
	Wax ka cawda maan maqal.

	Ma cod dheera waa gabadh;
	Xishood baa u caado ah.
	Cimri waa u gaban weli;
	Caqli waa u waayeel;
	Cidhib baanay leedahay.

	Aniguna ma caasiyo
	cadraddii ammaan lehe,
	Carshigii jamaalkaan
	U caleemo-saareee,
	Adna Cadar Hadraawoow
	Hambalyada u soo curi.

'''
    ),
    GabayoModel(
      title: 'Hoshi Cosob',
      gabayga: '''


   Caroogga saboolka,
   Adduunka ku ciillan
   Anaa cudha haysta.

   Anaa Cabdillaahi
   War-geys u ah caydha.
   Caloosha danleeyda,
   Anaa cabbiraaya.

   Anaa carrabkayga
   Xammaalku cabbaayo,
   U diiday cir-weyne
   Inaan ku casuumo.

   Gafuur cadho yeelki
   Intaan cosob-raaco,
   Wallee is-ma caayo.

   Waxsay tahay caawa
   Calaacalimaayo.
   Hal baa curanaysa;

   Ufaa caranaysa;
   Malaa cir da'aaya
   U sii ah calaamad.

   Ciyoowga higgooday
   Wuxuu ka cif-leeyey,
   Colaad ka horreysa
   Cagaar hiri doona.

   Haddeerse caleenta
   Xagaagu caddeeyey
   Cimraa u run-sheegay.
   Dhurwaaga ciyaaya
   Cabaadku naf weeye.

   Cadceed-galabeedku
   Godkay cidhif joogto
   Dan bay ugu ciiri.

   Wax taasi la cayn ah
   Cadaawe jabaaya
   Haddaan helo ciidan.

   Intaa cuti koow dheh
   Su'aal yarna ii cug.
   Ayaa ku cadaadshay?
   Waxaad dhaqday deer-cad
   Ayaw jaray cawda?

   Shabeelki Cagoole
   Hadduu dad-cunoobay
   Jidh caato ah doonay
   Caddiinkana diiday,
   Hadmaad u cadiigsan?
   Hadmaad ka cad-goosan?

   Haddaad caqli leeday
   Intaad cilmi-baadho,
   Car suuqa madoobi
   Cidduu yahay soo hel!

   Cagaarka la  leefay
   Cirroolaha baahan
   Ciyaalka jal beelay,
   Hablaa carcaraafay
   Cibaarada joogta
   Canaanta ayaa leh?

   Ma jeeblahan cawlan
   Ayaa ku curyaanshay?
   Kumaa cadawgaa ah?
   Nin kuu cudud-sheegtay
   Dhashaadana caydhshay;

   Nimuu camalkiisu
   Jar dheer kala ciiray;
   Nin ceebta korkiisa
   Caddaan ugu taalla
   Aroorba cid saara,
   Maxaad u cawaansan?

   Fulaa cararaaya
   Maxaad ugu ciidmi?
   Dhiqlaa ku cunaaya
   Intaad ka cabsooto,
   Maxaad naf cagaagan
   Islaan cimri-goys ah

   Cibaado sabool ah
   Culayska u saari?
   Miyaan cadda-loolka
   Habeenki ciyaarta
   Carruurtu ku heesin

   "Maroodi cadhoole":
   "Haddii col la sheego"
   "Cadaadda-ku-meere!"
   "Hashii cosob waa tan
'''
    ),
    GabayoModel(
      title: 'Damaq iyo Xasuus',
      gabayga: '''

Xilli waliba deeqdii;
Xero waliba qaadkeed;
Gammaan waliba xooggii;
Tulud waliba xoorkeed;
Xeer-beegti garadkeed
Xaajana guddoonkeed.

Xog-ogaal tibaaxdii;
Xulad waliba qiiqqii;
Maanso xarakadaynteed;
Xigsin Ina Suldaan galay
Xiisaheeda gaarka ah.

Geeriyeey xijaabaay!
Xejiyaay fogeeyaay!
Xaasha e af-tahannimo,
Haddii uu xabaal galay
Xeel-dheereheediii;

Haddii aan bud-dhigay xalay
Abwaankii xiddigin jirey,
Murtidii xag loo dayo
Xulashada ahayd iyo,
Xarragada higgaaddii
Ayaa xarafki hoos-dhabi?
Faraskii xiddaysnaa
Xakamihi ayaa sudhi?

Codkiisii xarraankiyo
Ka madhnaa xabeebtee
Xuli jirey wadnaha ee,
Wixii xay ah daayoo
Xawaallada gilgili jirey;
Geelana xasilin jirey;
Xoor gudhay hadduu yahay
Xaaddaydi yaa kicin?

Gabaygii xalaashiyo
Xaqa sheeg ha joogtee,
Dan ku xeeban jirinee
Xeelli-hadal ku caan-baxay;
Mabda'aan la xadi jirin
Suugaanta xaramka ah
Xushmadeedi yaa marin?

Xayndaabki maansada
Xanfaleeyda qaaddaay!
Haddaad jabisay xeerkii,
Anna damaq xusuuseed
Adna daniyo xeeshaa
Waa xabag-cadaadeed.

Kabo Caseeye

Waa curub abaadday;
  Waa laan cusayb ah
  Oo ciiro fuushay;
  Curdin weeye qaadhay;
  Waa cudur jidh yeeshay;
  Waa baahi cago leh;
  Waa ciil dad-weyne
  Canug laga sameeyey.

  Caynkuu u eeg yey
  Carrab laguma koobo;
  Waa caato miiqan
  Oo caday ka dhuuban.

  Waa ciirsi-laawe;
  Waa kabo-caseeye
  Ceel-gaabta jooga.

  Waa caado-goys yar;
  Ma yaqaan cisaynta
  Qofna kama cabsoodo;
  Waa cadho gadhoodhay.

  Casar buu agtayda,
  Isagoo cagaagan
  Oo caano-waaye
  Baatrool cabbaaya,
  Anoon caanad haysan
  Kaga cawday gaajo;
  Oo aanan caawin.

  Sidii ruux canaaday
  Goortuu cabbaar yar
  Isha igu canaantay,
  Waxa caratay siigo
  calooshiisa qaawan
  Markii ay ku ciirtay
  Masraxii cadaabta
  Oo car iyo bay la'
  Calalkii ka fayday;
  kana curatay sheeko.

  Cayayaanki fiirshay
  Cartanaw boggiisa
  Boogaha cunaayey.

  Dukhsi aad col mooddo
  Oon cadad lahayni,
  Caabuqi korkiisa
  Durba caasha saare.

  Carcartiyo kulaylka
  Kokuu caydhshu guuto
  Cutub soo hor yeelay.

  Anna camal-wareeray;
  Caal-waa daraadi
  Ciddiyaha qaniinay.

  Waxna cirirka gaaxday
  Igu sii cusleeyey,
  Cagiduu dhaqaaqay
  Ciidan baa taxaabay;
  Lagu yidhi ciyaalka
  Cid dar yeesha haysan
  Ee aragga cawlan,
  Si na loogu caayin
  Ku cabbeeya gaadhi.

  Sababtoo ah caawa,
  Waxa yimi Curuuba
  Dhawr wafdoo caddaan ah
  Iyo qaar Ciraaq ah;
  Oo Cabbaas i leeyey
  Waxa loo casuumay
  Sannadkii carruurta.
'''
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
       backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Container(child: Text('Gabayadii Maxamed Xaashi Gaariye',style: TextStyle(fontSize: 20,color: Colors.white),)),
        backgroundColor: Color.fromARGB(255, 108, 232, 249),
        elevation: 0,
      ),
    body: ListView.builder(
            itemCount: gb.length, 
            itemBuilder: (context, index) => gabayo(
              gab: gb[index],
              ),)
    );
  }
}

class gabayo extends StatelessWidget {
  const gabayo({
    Key? key, required this.gab,
  }) : super(key: key);
final GabayoModel gab;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => Detail(gab: gab),));
      },
      child: Container(
       height: 80,
       width: double.infinity,
       padding: EdgeInsets.only(left: 20,top: 20),
       margin: EdgeInsets.only(top: 10),
       decoration: BoxDecoration(
         color: Colors.white,
         borderRadius: BorderRadius.circular(15)
       ),
       child: Text(gab.title??'',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
      ),
    );
  }
}








class Detail extends StatelessWidget {
  const Detail({Key? key, required this.gab}) : super(key: key);
final GabayoModel gab;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Container(child: Text(gab.title??'',style: TextStyle(fontSize: 20,color: Colors.white),)),
        backgroundColor: Color.fromARGB(255, 108, 232, 249),
        elevation: 0,
      ),
      body: ListView(
        children: [
          Container(
            margin: EdgeInsets.only(top: 35,left: 35,right: 20),
            
            width: double.infinity,
            
            child: Text(gab.gabayga??'',
            style: TextStyle(fontSize: 20,fontWeight: FontWeight.w400,),),
          )
        ],
      ),

    );
  }
}