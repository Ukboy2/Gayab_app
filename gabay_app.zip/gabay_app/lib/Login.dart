import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:gabay_app/Home.dart';
import 'package:gabay_app/Singin.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';


class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {

final auth = FirebaseAuth.instance;
  TextEditingController username = TextEditingController();
  TextEditingController password = TextEditingController();
  bool isLoading = false;

  Login() async {
    isLoading = true;
    setState(() {});

    try {
    await  auth.signInWithEmailAndPassword(email: username.text, password: password.text);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('SUCCESS')));
    
    } catch (e) {
      print(e);
    }
     isLoading = false;
    setState(() {});
  }
  @override
  Widget build(BuildContext context) {
    return ModalProgressHUD(
      inAsyncCall: isLoading,
      child: Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
          title: Container(child: Text('Login',style: TextStyle(fontSize: 20,color: Colors.white),)),
          backgroundColor: Color.fromARGB(255, 108, 232, 249),      
          elevation: 0,
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

             Container(
        margin: EdgeInsets.only(left: 15,top: 30,right: 20),
        padding: EdgeInsets.only(left: 10,right: 10,bottom: 5,top: 5),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: Colors.grey.shade200,
        ),
        child: TextField(
          
          controller: username,
              decoration: InputDecoration(
                hintText: 'Emali',
                border: InputBorder.none,
                //suffixIcon: Icon(CupertinoIcons.search),
                //suffix: Icon(Icons.person),
               prefixIcon: Icon(CupertinoIcons.person_fill),
              
              ),
            ),
      ),
      Container(
        margin: EdgeInsets.only(left: 15,top: 30,right: 20),
        padding: EdgeInsets.only(left: 10,right: 10,bottom: 5,top: 5),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: Colors.grey.shade200,
        ),
        child: TextField(
          obscureText: true,
          controller: password,
              decoration: InputDecoration(
                hintText: 'Password',
                border: InputBorder.none,
                //suffixIcon: Icon(CupertinoIcons.search),
                //suffix: Icon(Icons.person),
               prefixIcon: Icon(CupertinoIcons.lock_fill),
              
              ),
            ),
      ),




            SizedBox(height: 40,),
            Container(
              width: double.infinity,
              height: 55,
              margin: EdgeInsets.only(left: 15,right: 20),
              child: ElevatedButton(onPressed:() {
                Login();
                //Navigator.push(context, MaterialPageRoute(builder: (context) => Home(),));

              },
               child: Text('Login',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w600),),
               style: ElevatedButton.styleFrom(
                primary: Colors.pink,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)
                )
               ),
               ),
            ),
            GestureDetector(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => Singin(),));
              },
              child: Container(
                margin: EdgeInsets.only(top: 10,left: 20),
                child: Text('Create Account',style: TextStyle(fontSize: 16,fontWeight: FontWeight.w500,color: Colors.blue), ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
