import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:gabay_app/drawer.dart';

class about extends StatelessWidget {
  const about({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: drawe(),
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: Container(child: Text('About Us',style: TextStyle(fontSize: 20,color: Colors.white),)),
        backgroundColor: Color.fromARGB(255, 108, 232, 249),      
        elevation: 0,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: EdgeInsets.only(top: 30,left: 100),
            child: ClipOval(child: Image.asset('Images/me.jpeg',fit: BoxFit.cover,height: 200,width: 200,)),
          ),
          SizedBox(height: 40,),
          abot(name: 'Name',detail: 'Abdirahmaan Mohamed Shukri',),
          SizedBox(height: 40,),
          abot(name: 'Work',detail: 'Developer',),
          SizedBox(height: 40,),
          abot(name: 'Email',detail: 'abdirahmaanmohamed90@gmail.com',),
          SizedBox(height: 40,),
          abot(name: 'Phone',detail: '+252 619147532',),
        ],
      ),
    );
  }
}

class abot extends StatelessWidget {
  const abot({
    Key? key, required this.name, required this.detail,
  }) : super(key: key);
  final String name;
  final String detail;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(left: 30),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(name,style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),),
          Text(detail,style: TextStyle(fontSize: 18,fontWeight: FontWeight.w500,color: Colors.grey.shade600),),
        
        ],
      ),
    );
  }
}