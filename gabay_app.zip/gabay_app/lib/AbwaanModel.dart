class AbwaanModel{
  String? Image;
  String? name;
  String? gabayo;
  String? gabay1;
  AbwaanModel({
    this.Image,
    this.name,
    this.gabayo,
    this.gabay1,
  });
}