import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:gabay_app/Home.dart';
import 'package:gabay_app/about.dart';


class drawe extends StatelessWidget {
  const drawe({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {

    return Drawer(
      child: Container(
        decoration: BoxDecoration(
          color: Colors.pink
        ),
        child: menu(),
      ),
    );
  }
}

class menu extends StatelessWidget {
  const menu({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    
    return Column(
      children: [
        GestureDetector(
          onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => Home(),));
          },
          child: Container(
           width: double.infinity,
          height: 50,
            margin: EdgeInsets.only(left: 20,top: 50),
            padding: const EdgeInsets.all(8.0),
            child: 
            Text("Home",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 30,
              color: Colors.white,
            //  backgroundColor: Colors.cyan,
              
            ), 
            ),
             
          ),
        ),
          GestureDetector(
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => about(),));
            },
            child: Container(
         width: double.infinity,
        height: 50,
            margin: EdgeInsets.only(left: 20,top: 10),
            padding: const EdgeInsets.all(8.0),
            child: 
            Text("About Us",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 30,
              color: Colors.white,
            //  backgroundColor: Colors.cyan,
              
            ),),
            
        ),
          ),
        
      ],
    );
  }
}